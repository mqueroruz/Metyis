import os
import pandas as pd

if __name__ == "__main__":

# Read File
    data_path = r'\data\europe_hotel_booking_satisfaction.csv'
    dir_path  = os.getcwd()
    df        = pd.read_csv(dir_path+data_path)

# Data Processing
    # Delete ID column -> It gives useful no info
    df = df.drop(['id'],axis = 1)

    # Change to binary satisfaction
    df.satisfaction[df.satisfaction == 'neutral or dissatisfied'] = 0
    df.satisfaction[df.satisfaction == 'satisfied'] = 1

    # To numeric
    evaluation_target     = 'satisfaction'
    df[evaluation_target] = pd.to_numeric(df[evaluation_target])

    # Turn Age to group by range
    df['Range']= ''
    df.Range[df.Age.between(0,14)]   = 'Children'
    df.Range[df.Age.between(15,24)]  = 'Youth'
    df.Range[df.Age.between(25,64)]  = 'Adults'
    df.Range[df.Age.between(65,140)] = 'Seniors'

    # Drop age collumn
    df = df.drop(['Age'],axis = 1)

# Representation of Data
   
    category = 'Range'
    
    # Plot Range
    df[category].value_counts().plot(kind = 'pie', figsize=  (5,5))
    
    # Plot categories Mean Clasification
    temp_df   = df.groupby([category]).mean()
    values_df = temp_df.drop([evaluation_target],axis = 1)
    values_df.plot(kind = 'barh', figsize=  (5,5))
    result         = pd.concat([pd.DataFrame(temp_df.min()), pd.DataFrame(temp_df.idxmin())], axis=1)
    result.columns = ['Worst Mean Valuation', 'Range']
    result         = result.sort_values(by='Worst Mean Valuation')
    
    print('\n--- Worst Valuated metrics -----------------------------------\n')
    print(result)
    
    # Plot Range satisfaction
    sum_df = df[[category,evaluation_target]]
    sum_df = sum_df.groupby([category]).mean()
    sum_df.plot().set_ylim(0,1)
    result2         = pd.concat([pd.DataFrame(sum_df.min()), pd.DataFrame(sum_df.idxmin())], axis=1)
    result2.columns = ['Worst Mean Valuation', 'Range']
  
    print('\n--- Worst Range Valuation -----------------------------------\n')
    print(sum_df)
    

# Worst Group Valuation
    df_range  = {}
    sum_range = {}
    keys      = {}
    result3   = {}
    result4   = {}
    result5   = pd.DataFrame
    for r in list(df.Range.drop_duplicates()):
        
        # Filtering
        df_range[r] = df.loc[df['Range'] == r].reset_index(drop=True)
        
        # Definition of Dictionaries of Dictionaries
        result3[r]   = {}
        result4[r]   = {}
        sum_range[r] = {}
       
        for clasifier in list(df.columns[1:4]):
  
            # Mean of Range-Clafifier
            sum_range[r][clasifier] = df_range[r][[clasifier,evaluation_target]]
            sum_range[r][clasifier] = sum_range[r][clasifier].groupby([clasifier]).mean()
            result3[r][clasifier]   = pd.concat([pd.DataFrame(sum_range[r][clasifier].min()), pd.DataFrame(sum_range[r][clasifier].idxmin())], axis=1)
      
        result4[r] = pd.concat(result3[r].values(), ignore_index=True)
        keys[r]    = pd.DataFrame(result3[r].keys())
        result4[r] = pd.concat([result4[r], keys[r]], axis=1)
        result4[r]['Range'] = r
    
    result5 = pd.concat(result4.values(), ignore_index=True)
    keys    = pd.DataFrame(result4.keys())
    result5.columns = ['Mean', 'Clafified','Clasifier', 'Range']
    result5         = result5.sort_values(by='Mean').reset_index(drop=True)
    
    print('\n--- Worst Group Valuation ----------------------------------\n')
    print(result5)
